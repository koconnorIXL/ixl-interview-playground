#!/usr/bin/env node

const express = require('express')
const app = express()
const students = require('./data/students')

app.use(express.static('public'))

app.get('/api/roster', (req, res) => {
	const start = parseInt(req.query.start) || 0
	const limit = Math.min(parseInt(req.query.limit) || 10, 100)
	const q = req.query.q

	const matchingStudents = students.filter((student) => {
		return q
			? student.name.toLowerCase().indexOf(q.toLowerCase()) !== -1
			: true
	})

	res.setHeader('Content-Type', 'application/json')
	res.json({
		total: matchingStudents.length,
		results: matchingStudents.slice(start, start + limit),
	})
})

app.listen(3000, () => {
	console.log('Server started, spitting out students now')
})

module.exports = [
{
  "avatarUrl": "http://i3.kym-cdn.com/photos/images/original/000/692/145/49c.png",
  "name": "Jerry Lung",
  "grade": "F",
  "questionsAnswered": 11
},
{
  "avatarUrl": "http://vignette3.wikia.nocookie.net/adventuretimewithfinnandjake/images/9/97/S1e25_Finn_with_five_fingers.png/revision/latest?cb=20131128031157",
  "name": "Kyle Wilson",
  "grade": "C",
  "questionsAnswered": 83
},
{
  "avatarUrl": "http://vignette3.wikia.nocookie.net/rickandmorty/images/a/a6/Rick_Sanchez.png/revision/latest?cb=20160923150728",
  "name": "Kevin O'Connor",
  "grade": "A",
  "questionsAnswered": 89
},
{
  "avatarUrl": "http://vignette4.wikia.nocookie.net/studio-ghibli/images/f/fc/San_and_Moro.jpg/revision/latest?cb=20131020143408",
  "name": "Julia Zhu",
  "grade": "A",
  "questionsAnswered": 79
},
{
  "avatarUrl": "https://media1.giphy.com/media/90oAlG2jDJ8nC/200_s.gif",
  "name": "Yachen Sun",
  "grade": "B",
  "questionsAnswered": 72
},
{
  "avatarUrl": "https://s-media-cache-ak0.pinimg.com/originals/6d/84/9a/6d849a537527cd121e5330c40bec2f6e.png",
  "name": "Jiho Kim",
  "grade": "C",
  "questionsAnswered": 52
},
{
  "avatarUrl": "http://orig02.deviantart.net/e99a/f/2012/036/c/6/marceline_by_sircinnamon-d4orn7w.png",
  "name": "Suzanne Pelz",
  "grade": "C",
  "questionsAnswered": 32
},
{
  "avatarUrl": "http://vignette2.wikia.nocookie.net/adventuretimewithfinnandjake/images/0/0b/Blush.jpg/revision/latest?cb=20131031114000",
  "name": "Wenli Li",
  "grade": "D",
  "questionsAnswered": 16
},
{
  "avatarUrl": "http://orig11.deviantart.net/06cf/f/2016/191/e/8/ash_ketchum_render_by_tzblacktd-da9k0wb.png",
  "name": "James Liu",
  "grade": "D",
  "questionsAnswered": 55
},
{
  "avatarUrl": "http://www.absoluteanime.com/my_neighbor_totoro/catbus.jpg",
  "name": "Fang Kwei Chang",
  "grade": "B",
  "questionsAnswered": 67
},
{
  "avatarUrl": "http://www.timecave.net/anime/gallery/miyazaki/kiki/kiki6.jpg",
  "name": "Eli Kosminsky",
  "grade": "F",
  "questionsAnswered": 2
},
{
  "avatarUrl": "http://vignette3.wikia.nocookie.net/p__/images/2/2c/Haku_spirited_away.jpg/revision/latest?cb=20130729134308&path-prefix=protagonist",
  "name": "Ismael Menjivar",
  "grade": "C",
  "questionsAnswered": 98
},
{
  "avatarUrl": "https://s-media-cache-ak0.pinimg.com/originals/19/1c/fe/191cfeb48344d58d99c0a5680bd61d0c.jpg",
  "name": "Jocelyn Tang",
  "grade": "B",
  "questionsAnswered": 37
},
];

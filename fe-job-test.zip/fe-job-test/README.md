# Frontend Challenge

## Your Task

We've provided you with a simple Express server that provides an API for querying student roster data and serves up static content from the `public` directory.

We would like you to build a simple UI for searching these students by name and selecting a student to show more details. The search results should just show the student name, and the more detailed view should display all of the data you get back from the server for the selected student.

The goal is to see how you approach the basic problems of front-end applications and what your UX instincts are. We expect candidates to spend about 1-2 hours on this.

## Spec

* While the user is typing in their search string don't actually send the query to the API until it's been 1 second since their last keystroke, so as to avoid sending a million requests.
* Don't use any basic utility libraries (e.g. Lodash, Underscore, Ramda, jQuery).
* We strongly suggest using React if you need a frontend framework. We use all React here and you would have to learn it on the job anyways.

If you have some spare time at the end here are a few stretch goals:

* Add infinite scrolling for the search results
* Make your design responsive, so it works well across various screen & device sizes
* Polish the UI
* Allow filtering results by grade or rank by # of questions answered

Things we're looking for:

* Clean, readable, and organized code
* Easy-to-use and not-horrible-looking UI
* A solid understanding of front-end JS fundamentals

Things we're not looking for:

* Performance, unless it's really bad
* Cross-browser functionality (modern browser support is fine)

## Getting started

You can install dependencies and start up the server with a quick `npm install && npm start`. Once it is running you can hit the `public/index.html` page at http://localhost:3000 , which should show a "Hello, world" message.

The companies API lives at http://localhost:3000/api/roster . It takes in the following parameters:

| Query param | Effect |
| ----------- | ------ |
| q           | Limits the results to companies with names that match `q` |
| start       | Returns result starting at the `start`th result |
| limit       | Restricts the result set to include no more than `limit` results |

And returns results similar to this:

```js
{
  "total": 13,
  "results": [
    {
      "avatarUrl": "http://i3.kym-cdn.com/photos/images/original/000/692/145/49c.png",
      "name": "Jerry Lung",
      "grade": "F",
      "questionsAnswered": 11
    }
    ...
  ]
}
```

## Submission

You can submit in one of two ways: email a zip folder or create a GitHub repo.

### Zip folder

Just zip up your solution (minus the node_modules directory) and email it to the recruiter.

### GitHub Repo TODO: needs to be done

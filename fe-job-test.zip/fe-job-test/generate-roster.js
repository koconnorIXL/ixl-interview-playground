#!/usr/bin/env node

const fs = require('fs')
const MongoClient = require('mongodb').MongoClient
const chance = require('chance').Chance()

MongoClient.connect('mongodb://localhost:27018/bc-local', (err, db) => {
	db.collection('Students')
		.find(
			{ avatarUrl: { $ne: null } },
			{ _id: 0, avatarUrl: 1, name: 1 }
		)
		.limit(500)
		.toArray()
		.then(students => students.map(student => ({
			avatarUrl: student.avatarUrl,
			name: student.name,
			grade: student.grade,
			questionsAnswered: student.questionsAnswered,
		})))
		.then(fakeStudents => {
			fs.writeFileSync(
				'data/companies.js',
`module.exports = [
${fakeStudents.map(c => JSON.stringify(c, null, 2)).join(',\n')}
]`
			)
		})
		.then(() => { db.close() })
})
